<template>
  <Page msg="Welcome to Your Vue.js App"/>
</template>

<script>
import Page from './components/Page.vue'

export default {
  name: 'recosadmin',
  components: {
    Page
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
